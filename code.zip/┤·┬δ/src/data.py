from typing import Tuple, Optional
import os
import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

def _generate_synthetic(n_samples=1200, n_features=20, n_informative=6, n_redundant=4, random_state=42):
    X, y = make_classification(
        n_samples=n_samples,
        n_features=n_features,
        n_informative=n_informative,
        n_redundant=n_redundant,
        n_clusters_per_class=2,
        flip_y=0.02,
        class_sep=1.2,
        random_state=random_state
    )
    columns = [f"f{i}" for i in range(X.shape[1])]
    df = pd.DataFrame(X, columns=columns)
    df["label"] = y
    return df

def load_dataset(csv_path: str, target_column: str, test_size: float, seed: int
                 ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, list]:
    if csv_path and os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
    else:
        df = _generate_synthetic(random_state=seed)

    if target_column not in df.columns:
       
