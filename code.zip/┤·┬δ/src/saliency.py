import os
import cv2
import torch
import numpy as np
from skimage.transform import resize


def _load_u2net(weights_path: str):

    if os.path.exists(weights_path):
        from torch import nn
   
        model = torch.hub.load('xuebinqin/U-2-Net', 'u2net', pretrained=False)
        sd = torch.load(weights_path, map_location='cpu')
        model.load_state_dict(sd)
    else:
        model = torch.hub.load('xuebinqin/U-2-Net', 'u2net', pretrained=True)
    model.eval()
    return model

@torch.no_grad()
def u2net_saliency(image_bgr: np.ndarray, weights_path: str, out_size=256) -> np.ndarray:
    model = _load_u2net(weights_path)
    img = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (320, 320))
    tens = torch.from_numpy(img.astype(np.float32).transpose(2,0,1) / 255.).unsqueeze(0)
    sal = model(tens)[0]
    sal = sal.squeeze().cpu().numpy()
    sal = (sal - sal.min())/(sal.max()-sal.min() + 1e-8)
    sal = resize(sal, (out_size, out_size), anti_aliasing=True, preserve_range=True)
    return sal.astype(np.float32)


def saliency_concentration(saliency: np.ndarray) -> float:
    s = saliency.astype(np.float64)
    s = s / (s.sum() + 1e-12)       # p_i
    eps = 1e-12
    H = -(s * (np.log(s + eps))).sum()  # 熵 H(S)
    N = s.size
    Cs = 1.0 - H / (np.log(N) + eps)    # Cs ∈ [0,1]
    return float(np.clip(Cs, 0.0, 1.0))
