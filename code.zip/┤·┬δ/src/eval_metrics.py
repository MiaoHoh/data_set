import numpy as np
from scipy.stats import pearsonr, spearmanr

def plcc(y_true, y_pred):
    r, _ = pearsonr(y_true, y_pred)
    return float(r)

def srcc(y_true, y_pred):
    r, _ = spearmanr(y_true, y_pred)
    return float(r)

def mae(y_true, y_pred):
    y_true = np.asarray(y_true); y_pred = np.asarray(y_pred)
    return float(np.mean(np.abs(y_true - y_pred)))

def rmse(y_true, y_pred):
    y_true = np.asarray(y_true); y_pred = np.asarray(y_pred)
    return float(np.sqrt(np.mean((y_true - y_pred)**2)))
