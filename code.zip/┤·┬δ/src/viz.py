import os, json, numpy as np, matplotlib.pyplot as plt
from PIL import Image
import cv2

def save_saliency_map(sal, out_path):
    sal8 = (sal*255).astype('uint8')
    cv2.imwrite(out_path, sal8)

def save_prob_bar(prob, out_path):
    ks = np.arange(1,11)
    plt.figure()
    plt.bar(ks, prob)
    plt.xlabel("Aesthetic Score (1-10)")
    plt.ylabel("Probability")
    plt.tight_layout()
    plt.savefig(out_path, dpi=160)
    plt.close()

def save_summary_json(dic, out_path):
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dic, f, ensure_ascii=False, indent=2)
