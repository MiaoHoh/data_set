def normalize_As(As: float) -> float:
    # A~ = (A-1)/9  ∈ [0,1]
    return max(0.0, min(1.0, (As - 1.0) / 9.0))

def joint_score(Cs: float, As: float, alpha: float = 0.4) -> float:
    A_tilde = normalize_As(As)
    Q = alpha * Cs + (1.0 - alpha) * A_tilde
    return float(Q)
