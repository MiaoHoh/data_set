
import random, numpy as np, cv2
from PIL import Image

def rand_in(a,b): return a + (b-a) * random.random()

def perturb_geometric(img, rotate_deg=3, translate_px=10, scale_range=(0.95,1.05)):
    h,w = img.shape[:2]
    angle = rand_in(-rotate_deg, rotate_deg)
    sx = rand_in(scale_range[0], scale_range[1])
    sy = rand_in(scale_range[0], scale_range[1])
    tx = rand_in(-translate_px, translate_px)
    ty = rand_in(-translate_px, translate_px)

    M = cv2.getRotationMatrix2D((w/2,h/2), angle, 1.0)
    M[:,0] *= sx; M[:,1] *= sy
    M[:,2] += [tx, ty]
    out = cv2.warpAffine(img, M, (w,h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    return out

def perturb_color(img, brightness=(0.9,1.1), contrast=(0.9,1.1), saturation=(0.9,1.1), gamma=(0.95,1.05)):
    out = img.astype(np.float32) / 255.0
    # HSV 调整饱和度与亮度
    hsv = cv2.cvtColor((out*255).astype(np.uint8), cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[...,1] *= rand_in(*saturation)
    hsv[...,2] *= rand_in(*brightness)
    hsv = np.clip(hsv, 0, 255).astype(np.uint8)
    out = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR).astype(np.float32)/255.0
    # 对比度
    c = rand_in(*contrast)
    out = np.clip((out - 0.5) * c + 0.5, 0, 1)
    # gamma
    g = rand_in(*gamma)
    out = np.clip(out ** (1.0/g), 0, 1)
    return (out*255).astype(np.uint8)

def generate_candidates(img_bgr, n, geom_cfg, color_cfg):
    cand = []
    for _ in range(n):
        x = perturb_geometric(img_bgr, **geom_cfg)
        x = perturb_color(x, **color_cfg)
        cand.append(x)
    return cand
