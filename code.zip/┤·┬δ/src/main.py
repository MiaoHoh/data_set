import os, argparse, cv2, pandas as pd, numpy as np
from PIL import Image
from tqdm import tqdm
from .utils import set_seed, ensure_dir, save_json
from .saliency import u2net_saliency, saliency_concentration
from .aesthetic import nima_score
from .joint_score import joint_score
from .optimize import generate_candidates
from .eval_metrics import plcc, srcc, mae, rmse
from . import viz
import yaml

def load_cfg(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def _eval_single(image_path, cfg, save_dir):
    img = cv2.imread(image_path)
    assert img is not None, f"Cannot read image: {image_path}"

    # 1) saliency → Cs
    sal = u2net_saliency(img, cfg["models"]["u2net"]["weights"], out_size=cfg["image_size"])
    Cs = saliency_concentration(sal)

    # 2) NIMA → As
    As_prob, As, As_var = nima_score(Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)),
                                     cfg["models"]["nima"]["weights"])

    # 3) Joint Q
    Q = joint_score(Cs, As, alpha=cfg["alpha"])

    # 保存
    ensure_dir(save_dir)
    viz.save_saliency_map(sal, os.path.join(save_dir, "saliency.png"))
    viz.save_prob_bar(As_prob, os.path.join(save_dir, "nima_prob.png"))
    out = {
        "Cs": Cs,
        "As": As,
        "As_var": As_var,
        "Q": Q,
        "alpha": cfg["alpha"],
        "image": image_path
    }
    viz.save_summary_json(out, os.path.join(save_dir, "summary.json"))
    return out

def _dataset_eval(dataset_cfg, cfg, save_dir):
    df = pd.read_csv(dataset_cfg["csv"])
    root = dataset_cfg.get("root", "")
    y_true, y_pred = [], []
    rows = []

    for _, row in tqdm(df.iterrows(), total=len(df)):
        path = row["image_path"]
        if root and not os.path.isabs(path):
            path = os.path.join(root, path)
        res = _eval_single(path, cfg, os.path.join(save_dir, "samples", os.path.basename(path)))
        y_true.append(float(row["mean_score"]))
        y_pred.append(float(res["As"]))  # 也可换成 Q 做对比

        rows.append({**res, "gt_mean": float(row["mean_score"])})

    metrics = {
        "PLCC": plcc(y_true, y_pred),
        "SRCC": srcc(y_true, y_pred),
        "MAE": mae(y_true, y_pred),
        "RMSE": rmse(y_true, y_pred),
    }
    save_json(metrics, os.path.join(save_dir, "metrics.json"))
    pd.DataFrame(rows).to_csv(os.path.join(save_dir, "per_image_results.csv"), index=False)
    return metrics

def _optimize(image_path, cfg, save_dir, num_candidates):
    img = cv2.imread(image_path); assert img is not None
    geom_cfg = cfg["optimize"]["geom"]; color_cfg = cfg["optimize"]["color"]
    cands = generate_candidates(img, num_candidates, geom_cfg, color_cfg)
    best = {"Q": -1, "idx": -1}
    for i, im in enumerate(cands):
        sal = u2net_saliency(im, cfg["models"]["u2net"]["weights"], out_size=cfg["image_size"])
        Cs = saliency_concentration(sal)
        _, As, _ = nima_score(Image.fromarray(cv2.cvtColor(im, cv2.COLOR_BGR2RGB)),
                              cfg["models"]["nima"]["weights"])
        Q = joint_score(Cs, As, cfg["alpha"])
        if Q > best["Q"]:
            best.update({"Q": Q, "idx": i, "Cs": Cs, "As": As, "sal": sal, "img": im})
    # 导出最佳候选
    ensure_dir(save_dir)
    cv2.imwrite(os.path.join(save_dir, "best.png"), best["img"])
    viz.save_saliency_map(best["sal"], os.path.join(save_dir, "best_saliency.png"))
    save_json({"best_Q": best["Q"], "best_Cs": best["Cs"], "best_As": best["As"]},
              os.path.join(save_dir, "best_summary.json"))
    return best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["single", "dataset", "optimize"], required=True)
    ap.add_argument("--image", type=str)
    ap.add_argument("--dataset_config", type=str)
    ap.add_argument("--config", type=str, required=True)
    ap.add_argument("--num_candidates", type=int, default=16)
    args = ap.parse_args()

    cfg = load_cfg(args.config)
    set_seed(cfg.get("seed", 42))
    save_root = os.path.join(cfg["save_dir"], args.mode)
    ensure_dir(save_root)

    if args.mode == "single":
        assert args.image, "--image required"
        out = _eval_single(args.image, cfg, os.path.join(save_root, os.path.splitext(os.path.basename(args.image))[0]))
        print(out)

    elif args.mode == "dataset":
        assert args.dataset_config, "--dataset_config required"
        ds = load_cfg(args.dataset_config)
        metrics = _dataset_eval(ds, cfg, os.path.join(save_root, "eval"))
        print(metrics)

    elif args.mode == "optimize":
        assert args.image, "--image required"
        best = _optimize(args.image, cfg, os.path.join(save_root, os.path.splitext(os.path.basename(args.image))[0]), args.num_candidates)
        print({"best_Q": best["Q"], "idx": best["idx"]})

if __name__ == "__main__":
    main()
