import os, torch, torch.nn as nn, torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image
import numpy as np

class NIMAMobileNet(nn.Module):

    def __init__(self):
        super().__init__()
        base = models.mobilenet_v2(weights=models.MobileNet_V2_Weights.IMAGENET1K_V2)
        feat_dim = base.classifier[1].in_features
        base.classifier[1] = nn.Identity()
        self.backbone = base
        self.head = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(feat_dim, 10)
        )

    def forward(self, x):
        f = self.backbone(x)
        logits = self.head(f)
        prob = F.softmax(logits, dim=1)
        return prob

    def load_nima_weights(self, path: str):
        if os.path.exists(path):
            sd = torch.load(path, map_location='cpu')
            self.load_state_dict(sd, strict=False)
        else:
            
            pass

_nima_tf = transforms.Compose([
    transforms.Resize((256,256)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
])

@torch.no_grad()
def nima_score(image_pil: Image.Image, weights_path: str):
    model = NIMAMobileNet().eval()
    model.load_nima_weights(weights_path)

    x = _nima_tf(image_pil).unsqueeze(0)
    prob = model(x).cpu().numpy()[0]  # p1..p10
    ks = np.arange(1,11, dtype=np.float32)
    As = float((ks * prob).sum())     
    var = float(((ks - As)**2 * prob).sum())
    return prob, As, var
