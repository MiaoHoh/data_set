from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import yaml

@dataclass
class DataConfig:
    csv_path: str
    target_column: str
    test_size: float
    standardize: bool

@dataclass
class ModelConfig:
    type: str
    params: Dict[str, Any]

@dataclass
class TrainConfig:
    cv_folds: int
    n_jobs: int

@dataclass
class ExperimentConfig:
    experiment_name: str
    seed: int
    output_dir: str
    data: DataConfig
    model: ModelConfig
    train: TrainConfig
    metrics: List[str]

def load_config(path: str) -> ExperimentConfig:
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    data = DataConfig(**cfg["data"])
    model = ModelConfig(**cfg["model"])
    train = TrainConfig(**cfg["train"])

    return ExperimentConfig(
        experiment_name=cfg["experiment_name"],
        seed=cfg["seed"],
        output_dir=cfg["output_dir"],
        data=data,
        model=model,
        train=train,
        metrics=cfg.get("metrics", []),
    )
